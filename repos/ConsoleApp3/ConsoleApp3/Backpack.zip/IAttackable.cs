﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards
{
    interface IAttackable
    {
        void Attack(Character character);
        

    }
}
