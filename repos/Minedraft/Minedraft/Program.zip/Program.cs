﻿using System;

namespace Minedraft
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
